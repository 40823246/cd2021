# File created by Thibaut Royer, Epitech school
# thibaut1.royer@epitech.eu
# It intends to be an example program for the "Two wheels, one arm" educative project.

import sim as vrep
import math
import random
import time
import keyboard
import numpy as np


print ('Start')

# Close eventual old connections
vrep.simxFinish(-1)
# Connect to V-REP remote server
clientID = vrep.simxStart('192.168.1.116', 19997, True, True, 5000, 5)

if clientID != -1:
    print ('Connected to remote API server')
    
    res = vrep.simxAddStatusbarMessage(
        clientID, "40823246",
        vrep.simx_opmode_oneshot)
    if res not in (vrep.simx_return_ok, vrep.simx_return_novalue_flag):
        print("Could not add a message to the status bar.")

    
    opmode = vrep.simx_opmode_oneshot_wait
    angle=math.pi/180
    

    
    vrep.simxStartSimulation(clientID, opmode)
    
    #設定軸對應名稱(堆高機)-----
    ret,rightF_handle=vrep.simxGetObjectHandle(clientID,"right_jointF",opmode)
    ret,leftF_handle=vrep.simxGetObjectHandle(clientID,"left_jointF",opmode)
    ret,left_handle=vrep.simxGetObjectHandle(clientID,"left_joint",opmode)
    ret,right_handle=vrep.simxGetObjectHandle(clientID,"right_joint",opmode)
    ret,gear_handle=vrep.simxGetObjectHandle(clientID,"gear_joint",opmode)
    ret,up_handle=vrep.simxGetObjectHandle(clientID,"up_joint",opmode)
    #設定軸對應名稱(堆高機)-----
    
    #設定軸對應名稱(夾爪)-----
    ret,vertical_handle=vrep.simxGetObjectHandle(clientID,"Prismatic_joint",opmode)
    ret,cam_handle=vrep.simxGetObjectHandle(clientID,"Revolute_joint",opmode)
    #設定軸對應名稱(夾爪)-----
    
    #設定軸對應名稱(影像辨識器)-----
    ret,vision_handle=vrep.simxGetObjectHandle(clientID,"Vision_sensor",opmode)
    #設定軸對應名稱(影像辨識器)-----
    
    vrep.simxSetJointTargetPosition(clientID,vertical_handle,0.1,opmode)
    
    while True:
        #rgb辨識-----
        returnCode,resolution,image=vrep.simxGetVisionSensorImage(clientID,vision_handle,0,opmode)#取得圖片
        color = np.asarray(image)#將圖片數據轉成矩陣形式
        color.shape = (resolution[1], resolution[0], 3)
        color = color.astype(np.float)#-1~1
        color[color < 0] += 255
        color = np.fliplr(color)#因為得到得圖片數據是上下左右顛倒的，所以要將數據在顛倒一次才能轉正
        color = color.astype(np.uint8)#0~255
        rgb=color[1]
        rgb2=rgb[1]
        print(rgb2)
        rgb3=[139,139,163]#掃地機器人的顏色
        rgb4=[0,0,147]
        #rgb辨識-----
        
        #夾爪程式(rgb作動)-----
        if all(rgb2==rgb3):
            vrep.simxSetJointTargetPosition(clientID,vertical_handle,0.5,opmode)
            time.sleep(0.5)
            vrep.simxSetJointTargetPosition(clientID,cam_handle,angle*90,opmode)
            time.sleep(0.5)
            vrep.simxSetJointTargetPosition(clientID,vertical_handle,0.1,opmode)
            time.sleep(5)
            vrep.simxSetJointTargetPosition(clientID,cam_handle,angle*0,opmode)
        #夾爪程式(rgb作動)-----
        
        #堆高機-----
        #keyboard "w" 
        if keyboard.is_pressed("w"):
            vrep.simxSetJointTargetVelocity(clientID,rightF_handle,-2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,leftF_handle,-2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,left_handle,2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,right_handle,2,opmode)
            
        #keyboard "s" 
        if keyboard.is_pressed("s"):
            vrep.simxSetJointTargetVelocity(clientID,rightF_handle,2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,leftF_handle,2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,left_handle,-2,opmode)
            vrep.simxSetJointTargetVelocity(clientID,right_handle,-2,opmode)
        
        #keyboard "a" 
        if keyboard.is_pressed("a"):
            vrep.simxSetJointTargetVelocity(clientID,rightF_handle,-1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,leftF_handle,1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,left_handle,-1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,right_handle,1,opmode)
        
        #keyboard "d" 
        if keyboard.is_pressed("d"):
            vrep.simxSetJointTargetVelocity(clientID,rightF_handle,1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,leftF_handle,-1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,left_handle,1,opmode)
            vrep.simxSetJointTargetVelocity(clientID,right_handle,-1,opmode)
        
        
        #keyboard "space" 
        if keyboard.is_pressed("space"):
            vrep.simxSetJointTargetVelocity(clientID,rightF_handle,0,opmode)
            vrep.simxSetJointTargetVelocity(clientID,leftF_handle,0,opmode)
            vrep.simxSetJointTargetVelocity(clientID,left_handle,0,opmode)
            vrep.simxSetJointTargetVelocity(clientID,right_handle,0,opmode)
            vrep.simxSetJointTargetVelocity(clientID,up_handle,0,opmode)
        
        #keyboard "8" 
        if keyboard.is_pressed("8"):
            vrep.simxSetJointTargetVelocity(clientID,up_handle,0.2,opmode)
        
        #keyboard "5" 
        if keyboard.is_pressed("5"):
            vrep.simxSetJointTargetVelocity(clientID,up_handle,-0.2,opmode)
        #堆高機-----    
        
        #夾爪-----
        if keyboard.is_pressed("t"):
            print("You pressed t")
           
            vrep.simxSetJointTargetPosition(clientID,vertical_handle,0.5,opmode)
            time.sleep(0.5)
            vrep.simxSetJointTargetPosition(clientID,cam_handle,angle*90,opmode)
            time.sleep(0.5)
            vrep.simxSetJointTargetPosition(clientID,vertical_handle,0.1,opmode)
            time.sleep(5)
            vrep.simxSetJointTargetPosition(clientID,cam_handle,angle*0,opmode)
        #夾爪-----   
        
        #keyboard "esc" (結束程式)-----
        if  keyboard.is_pressed("esc"):
            vrep.simxStopSimulation(clientID, opmode)
            break
        #keyboard "esc" (結束程式)-----
        
else:
    print ('Failed connecting to remote API server')
    print ('End')